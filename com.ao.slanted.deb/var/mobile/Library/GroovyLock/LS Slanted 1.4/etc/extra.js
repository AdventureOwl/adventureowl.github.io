//AHHHHH!! DON'T TOUCH THESE BAD BOYS!
var loaded = false;
var note = false;
//setting these to true will probably mess up notifications
//don't do it man