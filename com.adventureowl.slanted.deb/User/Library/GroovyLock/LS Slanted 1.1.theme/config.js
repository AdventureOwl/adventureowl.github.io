var showdate = true;
//set to true to show the date
//set to false to show the battery state (charging or unplugged)